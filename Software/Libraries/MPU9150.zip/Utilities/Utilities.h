String floatToString(float f, int decimals = 2){
	/*
		Transforms the floating point string process:
		eg.: using decimals = 2, input: 0.01
			1.23456 * (pow(10, 2+1)
				1.23456 * 1000 = 1234 (as a long)
			now, let's move digits asside:
			3 goes to 4, 2 goes to 3.
			Stages:		"1234"
						"1233"
						"1223"
			Not, put a dot in the place of the separator
			"1.23"

	*/
	long fLong = f*(pow(10,decimals+1));
	String longString = String(fLong);
	int len = longString.length();

	for(int i = 0; i < decimals; i++){
		longString[len - 1 - i] = longString[len - 2 - i];
	}
	longString[len - decimals - 1] = '.';

	return longString;
}