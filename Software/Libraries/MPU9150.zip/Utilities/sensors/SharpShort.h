#ifndef SharpShort_h
#define SharpShort_h

#include "sensors/AnalogIn.h"
#include "sensors/DistanceInterface.h"

class SharpShort: public AnalogIn, public DistanceInterface
{
protected:
	long distance;

public:
	SharpShort(int _pin){
		setup(_pin);

		distance = 0;
	}

	long getDistance(){
		return distance;
	}

	long readDistance(){
		read();
		return distance;
	}

	virtual long read(){
		AnalogIn::read();

		// Calculate real Centimiter value
		if (value > 600){  // lower boundary: 4 cm (3 cm means under the boundary)
			distance = 3;
		}else if (value < 80 ){  //upper boundary: 36 cm (returning 37 means over the boundary)
			distance = 37;
		}else{
			distance = (1 / (0.000413153 * value - 0.0055266887));
		}

		return value;
	}

};

#endif