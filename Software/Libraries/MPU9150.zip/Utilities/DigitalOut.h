#ifndef DigitalOut_h
#define DigitalOut_h

#define FAST

#include "Arduino.h"

class DigitalOut
{
protected:
	int outPin;

	bool invert;

public:

	// Pin: Analog pin to read value
	// Invert: Should invert the output signal?
	DigitalOut(int _outPin, bool _invert = false){
		outPin = _outPin;
		// pinMode(outPin, OUTPUT);

		invert = _invert;

		turnOn(false);
	}

	/*bool operator==(const bool other){
		return aboveThreshold();
	}*/

	void operator=(bool on){
		turnOn(on);
	}

	void turnOn(bool on = true){
		#ifndef FAST
			digitalWrite(outPin, on ^ invert);
		#else
			PIO_SetOutput( g_APinDescription[outPin].pPort, g_APinDescription[outPin].ulPin, on ^ invert, 0, PIO_PULLUP ) ;
		#endif
	}

	void turnOff(bool off = true){
		turnOn(!off);
	}

};

#endif